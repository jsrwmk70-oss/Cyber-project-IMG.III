#!/usr/bin/env python3
"""Generate sample cover images, hide a message in each, and verify the round trip."""

import math
import os
import random

from PIL import Image, ImageDraw

import stego

OUT = "samples"
os.makedirs(OUT, exist_ok=True)
random.seed(7)


def sunset(w=800, h=600):
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        t = y / h
        for x in range(w):
            px[x, y] = (int(255 * (1 - t * 0.4)), int(120 * (1 - t) + 40), int(180 * t + 40))
    d = ImageDraw.Draw(img)
    d.ellipse((w // 2 - 90, h // 2 - 90, w // 2 + 90, h // 2 + 90), fill=(255, 220, 120))
    d.rectangle((0, int(h * 0.75), w, h), fill=(25, 30, 60))
    return img


def noise_pattern(w=640, h=480):
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        for x in range(w):
            v = int(127 + 80 * math.sin(x / 25) * math.cos(y / 30))
            px[x, y] = (v + random.randint(-12, 12) & 255, (v // 2 + x // 8) & 255, (255 - v + random.randint(-12, 12)) & 255)
    return img


def shapes(w=640, h=480):
    img = Image.new("RGB", (w, h), (240, 240, 235))
    d = ImageDraw.Draw(img)
    for _ in range(40):
        x, y = random.randint(0, w), random.randint(0, h)
        r = random.randint(15, 70)
        col = tuple(random.randint(30, 230) for _ in range(3))
        if random.random() < 0.5:
            d.ellipse((x - r, y - r, x + r, y + r), fill=col)
        else:
            d.rectangle((x - r, y - r, x + r, y + r), fill=col)
    return img


covers = {"sunset": sunset(), "pattern": noise_pattern(), "shapes": shapes()}
messages = {
    "sunset": "Meet at the library at 6 PM. The password is 'blue-falcon-42'.",
    "pattern": "LSB steganography demo: this text is hidden in the least significant bits of this image.",
    "shapes": "Hidden in plain sight. Unicode works too: नमस्ते, héllo, 你好 🔐",
}

for name, img in covers.items():
    cover = f"{OUT}/{name}_cover.png"
    stegp = f"{OUT}/{name}_stego.png"
    img.save(cover)
    msg = messages[name].encode("utf-8")
    stego.encode(cover, stegp, msg)
    assert stego.decode(stegp) == msg, f"round trip failed for {name}"
    changed, total, max_diff, mse, psnr = stego.compare(cover, stegp)
    print(f"[OK] {name}: {len(msg)} bytes hidden | max pixel diff {max_diff} | PSNR {psnr:.1f} dB")

# Long-message sample: hide the project's own README-style text file
long_text = ("LSB steganography hides data in the least significant bit of pixel values. " * 40).encode()
stego.encode(f"{OUT}/sunset_cover.png", f"{OUT}/sunset_long_stego.png", long_text)
assert stego.decode(f"{OUT}/sunset_long_stego.png") == long_text
print(f"[OK] long message: {len(long_text)} bytes hidden in sunset_long_stego.png")

# Negative tests
try:
    stego.decode(f"{OUT}/sunset_cover.png")
    print("[FAIL] decoded a clean image")
except ValueError as e:
    print(f"[OK] clean image correctly rejected: {e}")
try:
    stego.encode(f"{OUT}/sunset_cover.png", f"{OUT}/x.png", b"A" * 10_000_000)
    print("[FAIL] oversize message accepted")
except ValueError as e:
    print(f"[OK] oversize message correctly rejected")
